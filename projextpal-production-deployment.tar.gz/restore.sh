#!/bin/bash

# ============================================================
# ProjeXtPal Restore Script
# Restores: PostgreSQL database + Media files
# ============================================================

set -e  # Exit on error

# Configuration
BACKUP_DIR="./backups"
COMPOSE_FILE="docker-compose.production.yml"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🔄 ProjeXtPal Restore Utility${NC}"
echo "=================================="
echo ""

# ============================================================
# List available backups
# ============================================================
echo -e "${YELLOW}Available database backups:${NC}"
echo ""

DB_BACKUPS=($(ls -1t $BACKUP_DIR/database/db_backup_*.sql.gz 2>/dev/null))

if [ ${#DB_BACKUPS[@]} -eq 0 ]; then
    echo -e "${RED}❌ No database backups found!${NC}"
    exit 1
fi

# Display backups with numbers
for i in "${!DB_BACKUPS[@]}"; do
    BACKUP_FILE="${DB_BACKUPS[$i]}"
    BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    BACKUP_DATE=$(echo "$BACKUP_FILE" | grep -oP '\d{8}_\d{6}')
    FORMATTED_DATE=$(date -d "${BACKUP_DATE:0:8} ${BACKUP_DATE:9:2}:${BACKUP_DATE:11:2}:${BACKUP_DATE:13:2}" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "$BACKUP_DATE")
    echo "  [$i] $FORMATTED_DATE ($BACKUP_SIZE)"
done

echo ""

# ============================================================
# Select backup to restore
# ============================================================
read -p "Enter backup number to restore (or 'q' to quit): " SELECTION

if [ "$SELECTION" = "q" ]; then
    echo "Restore cancelled."
    exit 0
fi

if ! [[ "$SELECTION" =~ ^[0-9]+$ ]] || [ "$SELECTION" -ge "${#DB_BACKUPS[@]}" ]; then
    echo -e "${RED}❌ Invalid selection!${NC}"
    exit 1
fi

SELECTED_BACKUP="${DB_BACKUPS[$SELECTION]}"

echo ""
echo -e "${YELLOW}⚠️  WARNING: This will REPLACE the current database!${NC}"
echo "Selected backup: $SELECTED_BACKUP"
echo ""
read -p "Are you ABSOLUTELY sure? Type 'YES' to continue: " CONFIRMATION

if [ "$CONFIRMATION" != "YES" ]; then
    echo "Restore cancelled."
    exit 0
fi

echo ""

# ============================================================
# Restore Database
# ============================================================
echo -e "${BLUE}📦 Restoring database from backup...${NC}"

# Stop backend to prevent connections
echo "Stopping backend service..."
docker-compose -f $COMPOSE_FILE stop backend

# Drop and recreate database
echo "Recreating database..."
docker-compose -f $COMPOSE_FILE exec -T postgres psql -U postgres -c "DROP DATABASE IF EXISTS projextpal;"
docker-compose -f $COMPOSE_FILE exec -T postgres psql -U postgres -c "CREATE DATABASE projextpal OWNER projextpal;"

# Restore from backup
echo "Restoring data..."
gunzip -c "$SELECTED_BACKUP" | docker-compose -f $COMPOSE_FILE exec -T postgres psql -U projextpal projextpal

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Database restored successfully!${NC}"
else
    echo -e "${RED}❌ Database restore failed!${NC}"
    exit 1
fi

# ============================================================
# Restore Media Files (Optional)
# ============================================================
echo ""
echo -e "${YELLOW}Checking for media backup...${NC}"

# Find corresponding media backup
BACKUP_DATE=$(echo "$SELECTED_BACKUP" | grep -oP '\d{8}_\d{6}')
MEDIA_BACKUP="$BACKUP_DIR/media/media_backup_${BACKUP_DATE}.tar.gz"

if [ -f "$MEDIA_BACKUP" ]; then
    read -p "Restore media files too? (y/n): " RESTORE_MEDIA
    
    if [ "$RESTORE_MEDIA" = "y" ]; then
        echo "Restoring media files..."
        
        BACKEND_CONTAINER=$(docker-compose -f $COMPOSE_FILE ps -q backend)
        
        if [ -n "$BACKEND_CONTAINER" ]; then
            # Remove existing media
            docker-compose -f $COMPOSE_FILE exec backend rm -rf /app/media/*
            
            # Restore from backup
            gunzip -c "$MEDIA_BACKUP" | docker cp - $BACKEND_CONTAINER:/app/
            
            echo -e "${GREEN}✅ Media files restored successfully!${NC}"
        else
            echo -e "${RED}❌ Backend container not running!${NC}"
        fi
    fi
else
    echo -e "${YELLOW}⚠️  No corresponding media backup found${NC}"
fi

# ============================================================
# Restart Services
# ============================================================
echo ""
echo -e "${BLUE}🔄 Restarting services...${NC}"
docker-compose -f $COMPOSE_FILE start backend
docker-compose -f $COMPOSE_FILE restart

# Wait for services to be ready
sleep 5

# ============================================================
# Verify Restore
# ============================================================
echo ""
echo -e "${BLUE}🔍 Verifying restore...${NC}"

# Check database connection
docker-compose -f $COMPOSE_FILE exec backend python manage.py check --database default

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Database connection verified!${NC}"
else
    echo -e "${RED}❌ Database verification failed!${NC}"
fi

# ============================================================
# Summary
# ============================================================
echo ""
echo -e "${GREEN}✅ Restore completed!${NC}"
echo ""
echo "Summary:"
echo "  Database: Restored from $SELECTED_BACKUP"
[ -f "$MEDIA_BACKUP" ] && echo "  Media: Restored from $MEDIA_BACKUP"
echo ""
echo "Next steps:"
echo "  1. Verify data integrity"
echo "  2. Test application functionality"
echo "  3. Check logs: docker-compose -f $COMPOSE_FILE logs"
echo ""
