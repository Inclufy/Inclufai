#!/bin/bash

# ============================================================
# ProjeXtPal Automated Backup Script
# Backs up: PostgreSQL database + Media files
# ============================================================

set -e  # Exit on error

# Configuration
BACKUP_DIR="./backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30
COMPOSE_FILE="docker-compose.production.yml"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}🔄 ProjeXtPal Backup Started${NC}"
echo "Timestamp: $(date)"
echo ""

# ============================================================
# Create backup directory
# ============================================================
mkdir -p "$BACKUP_DIR/database"
mkdir -p "$BACKUP_DIR/media"

# ============================================================
# 1. Database Backup
# ============================================================
echo -e "${YELLOW}📦 Backing up PostgreSQL database...${NC}"

DB_BACKUP_FILE="$BACKUP_DIR/database/db_backup_$DATE.sql.gz"

docker-compose -f $COMPOSE_FILE exec -T postgres pg_dump -U projextpal projextpal | gzip > "$DB_BACKUP_FILE"

if [ $? -eq 0 ]; then
    DB_SIZE=$(du -h "$DB_BACKUP_FILE" | cut -f1)
    echo -e "${GREEN}✅ Database backup completed: $DB_BACKUP_FILE ($DB_SIZE)${NC}"
else
    echo -e "${RED}❌ Database backup failed!${NC}"
    exit 1
fi

# ============================================================
# 2. Media Files Backup
# ============================================================
echo -e "${YELLOW}📁 Backing up media files...${NC}"

MEDIA_BACKUP_FILE="$BACKUP_DIR/media/media_backup_$DATE.tar.gz"

# Get container ID for backend
BACKEND_CONTAINER=$(docker-compose -f $COMPOSE_FILE ps -q backend)

if [ -n "$BACKEND_CONTAINER" ]; then
    docker cp $BACKEND_CONTAINER:/app/media - | gzip > "$MEDIA_BACKUP_FILE"
    
    if [ $? -eq 0 ]; then
        MEDIA_SIZE=$(du -h "$MEDIA_BACKUP_FILE" | cut -f1)
        echo -e "${GREEN}✅ Media backup completed: $MEDIA_BACKUP_FILE ($MEDIA_SIZE)${NC}"
    else
        echo -e "${RED}❌ Media backup failed!${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  Backend container not running, skipping media backup${NC}"
fi

# ============================================================
# 3. Configuration Backup
# ============================================================
echo -e "${YELLOW}⚙️  Backing up configuration...${NC}"

CONFIG_BACKUP_FILE="$BACKUP_DIR/config_backup_$DATE.tar.gz"

tar -czf "$CONFIG_BACKUP_FILE" \
    .env.production \
    docker-compose.production.yml \
    2>/dev/null || true

if [ -f "$CONFIG_BACKUP_FILE" ]; then
    echo -e "${GREEN}✅ Configuration backup completed: $CONFIG_BACKUP_FILE${NC}"
fi

# ============================================================
# 4. Cleanup old backups
# ============================================================
echo -e "${YELLOW}🧹 Cleaning up old backups (older than $RETENTION_DAYS days)...${NC}"

# Database backups
DELETED_DB=$(find "$BACKUP_DIR/database" -name "db_backup_*.sql.gz" -mtime +$RETENTION_DAYS -delete -print | wc -l)
echo "   Deleted $DELETED_DB old database backups"

# Media backups
DELETED_MEDIA=$(find "$BACKUP_DIR/media" -name "media_backup_*.tar.gz" -mtime +$RETENTION_DAYS -delete -print | wc -l)
echo "   Deleted $DELETED_MEDIA old media backups"

# Config backups
DELETED_CONFIG=$(find "$BACKUP_DIR" -name "config_backup_*.tar.gz" -mtime +$RETENTION_DAYS -delete -print | wc -l)
echo "   Deleted $DELETED_CONFIG old config backups"

# ============================================================
# 5. Backup Summary
# ============================================================
echo ""
echo -e "${GREEN}✅ Backup completed successfully!${NC}"
echo ""
echo "Backup Summary:"
echo "  Database: $DB_BACKUP_FILE"
echo "  Media: $MEDIA_BACKUP_FILE"
echo "  Config: $CONFIG_BACKUP_FILE"
echo ""
echo "Current backups:"
echo "  Database backups: $(ls -1 $BACKUP_DIR/database/*.sql.gz 2>/dev/null | wc -l)"
echo "  Media backups: $(ls -1 $BACKUP_DIR/media/*.tar.gz 2>/dev/null | wc -l)"
echo "  Total size: $(du -sh $BACKUP_DIR | cut -f1)"
echo ""

# ============================================================
# Optional: Upload to remote storage
# ============================================================
# Uncomment to enable remote backup (requires configuration)

# if [ -n "$BACKUP_S3_BUCKET" ]; then
#     echo "Uploading to S3..."
#     aws s3 cp "$DB_BACKUP_FILE" "s3://$BACKUP_S3_BUCKET/projextpal/"
#     aws s3 cp "$MEDIA_BACKUP_FILE" "s3://$BACKUP_S3_BUCKET/projextpal/"
# fi

# if [ -n "$BACKUP_RSYNC_TARGET" ]; then
#     echo "Uploading via rsync..."
#     rsync -avz "$BACKUP_DIR/" "$BACKUP_RSYNC_TARGET"
# fi

echo "Backup completed at: $(date)"
