#!/bin/bash

# ============================================================
# Tailscale Setup Script for ProjeXtPal
# ============================================================

set -e  # Exit on error

echo "🔐 Tailscale Setup for ProjeXtPal"
echo "=================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ============================================================
# 1. Check if Tailscale is installed
# ============================================================
echo -e "${BLUE}Checking Tailscale installation...${NC}"

if command -v tailscale &> /dev/null; then
    echo -e "${GREEN}✅ Tailscale is installed${NC}"
    tailscale version
else
    echo -e "${YELLOW}⚠️  Tailscale not found. Installing...${NC}"
    
    # Install Tailscale
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        echo "Please install Tailscale from: https://tailscale.com/download/mac"
        exit 1
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        curl -fsSL https://tailscale.com/install.sh | sh
    else
        echo -e "${RED}❌ Unsupported OS. Please install Tailscale manually from: https://tailscale.com/download${NC}"
        exit 1
    fi
fi

echo ""

# ============================================================
# 2. Check if Tailscale is running
# ============================================================
echo -e "${BLUE}Checking Tailscale status...${NC}"

if tailscale status &> /dev/null; then
    echo -e "${GREEN}✅ Tailscale is running${NC}"
    tailscale status | head -5
else
    echo -e "${YELLOW}⚠️  Tailscale is not connected. Starting...${NC}"
    sudo tailscale up
fi

echo ""

# ============================================================
# 3. Get Tailscale IP
# ============================================================
echo -e "${BLUE}Getting Tailscale IP...${NC}"
TAILSCALE_IP=$(tailscale ip -4 2>/dev/null || echo "Not connected")

if [ "$TAILSCALE_IP" != "Not connected" ]; then
    echo -e "${GREEN}✅ Tailscale IP: $TAILSCALE_IP${NC}"
else
    echo -e "${RED}❌ Could not get Tailscale IP${NC}"
    exit 1
fi

echo ""

# ============================================================
# 4. Generate Auth Key Instructions
# ============================================================
echo -e "${YELLOW}📝 Auth Key Setup:${NC}"
echo ""
echo "To get a Tailscale auth key:"
echo "1. Go to: https://login.tailscale.com/admin/settings/keys"
echo "2. Click 'Generate auth key'"
echo "3. Options:"
echo "   - ✅ Reusable: Yes (for multiple containers)"
echo "   - ✅ Ephemeral: No (we want persistent)"
echo "   - ✅ Tags: prod (optional, for access control)"
echo "4. Copy the key (starts with tskey-auth-...)"
echo "5. Add it to .env.production as TAILSCALE_AUTHKEY"
echo ""

read -p "Do you have an auth key ready? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "Enter your Tailscale auth key: " TAILSCALE_KEY
    
    # Add to .env.production
    if [ -f ".env.production" ]; then
        sed -i.bak "s/TAILSCALE_AUTHKEY=.*/TAILSCALE_AUTHKEY=$TAILSCALE_KEY/" .env.production
        echo -e "${GREEN}✅ Auth key added to .env.production${NC}"
    else
        echo "TAILSCALE_AUTHKEY=$TAILSCALE_KEY" >> .env.production
        echo -e "${GREEN}✅ Created .env.production with auth key${NC}"
    fi
fi

echo ""

# ============================================================
# 5. Network Configuration
# ============================================================
echo -e "${BLUE}Tailscale Network Configuration:${NC}"
echo ""
echo "Your Tailscale network:"
echo "  Hostname: $(hostname)"
echo "  Tailscale IP: $TAILSCALE_IP"
echo "  Tailnet: $(tailscale status | grep -o 'tailscale.*.net' | head -1)"
echo ""

# ============================================================
# 6. Docker Network Setup
# ============================================================
echo -e "${YELLOW}🐳 Docker Network Setup:${NC}"
echo ""
echo "To use Tailscale with Docker:"
echo "1. The docker-compose.production.yml is configured"
echo "2. Container will be accessible at: http://${TAILSCALE_IP}"
echo "3. Or use MagicDNS hostname (if enabled)"
echo ""

# ============================================================
# 7. Firewall Rules (if applicable)
# ============================================================
echo -e "${BLUE}Checking firewall rules...${NC}"

if command -v ufw &> /dev/null; then
    echo "UFW detected. Allowing Tailscale:"
    sudo ufw allow in on tailscale0
    echo -e "${GREEN}✅ Firewall rule added for Tailscale${NC}"
elif command -v firewall-cmd &> /dev/null; then
    echo "Firewalld detected. Allowing Tailscale:"
    sudo firewall-cmd --permanent --add-interface=tailscale0
    sudo firewall-cmd --reload
    echo -e "${GREEN}✅ Firewall rule added for Tailscale${NC}"
else
    echo -e "${YELLOW}⚠️  No firewall detected or manual configuration needed${NC}"
fi

echo ""

# ============================================================
# 8. Summary
# ============================================================
echo -e "${GREEN}🎉 Tailscale Setup Complete!${NC}"
echo ""
echo "Next steps:"
echo "1. ✅ Update .env.production with TAILSCALE_AUTHKEY"
echo "2. ✅ Run: docker-compose -f docker-compose.production.yml up -d"
echo "3. ✅ Access your app at: http://$TAILSCALE_IP"
echo "4. ✅ Share with team via Tailscale network"
echo ""
echo "Useful commands:"
echo "  tailscale status      - Check connection"
echo "  tailscale ip          - Show your IP"
echo "  tailscale netcheck    - Test connectivity"
echo "  tailscale logout      - Disconnect"
echo ""
