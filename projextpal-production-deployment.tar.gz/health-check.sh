#!/bin/bash

# ============================================================
# ProjeXtPal Health Check & Monitoring Script
# ============================================================

COMPOSE_FILE="docker-compose.production.yml"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🏥 ProjeXtPal Health Check${NC}"
echo "=================================="
echo "Timestamp: $(date)"
echo ""

# ============================================================
# 1. Container Status
# ============================================================
echo -e "${YELLOW}📦 Container Status:${NC}"
docker-compose -f $COMPOSE_FILE ps

RUNNING=$(docker-compose -f $COMPOSE_FILE ps | grep "Up" | wc -l)
TOTAL=$(docker-compose -f $COMPOSE_FILE ps | tail -n +2 | wc -l)

echo ""
if [ $RUNNING -eq $TOTAL ] && [ $TOTAL -gt 0 ]; then
    echo -e "${GREEN}✅ All containers running ($RUNNING/$TOTAL)${NC}"
else
    echo -e "${RED}❌ Some containers are down ($RUNNING/$TOTAL)${NC}"
fi

echo ""

# ============================================================
# 2. Resource Usage
# ============================================================
echo -e "${YELLOW}💻 Resource Usage:${NC}"
docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}" | head -6

echo ""

# ============================================================
# 3. Database Connection
# ============================================================
echo -e "${YELLOW}🗄️  Database Health:${NC}"

DB_CHECK=$(docker-compose -f $COMPOSE_FILE exec -T postgres pg_isready -U projextpal 2>&1)

if echo "$DB_CHECK" | grep -q "accepting connections"; then
    echo -e "${GREEN}✅ PostgreSQL is healthy${NC}"
    
    # Get database size
    DB_SIZE=$(docker-compose -f $COMPOSE_FILE exec -T postgres psql -U projextpal -d projextpal -t -c "SELECT pg_size_pretty(pg_database_size('projextpal'));" 2>/dev/null | tr -d ' ')
    echo "   Database size: $DB_SIZE"
    
    # Get connection count
    CONNECTIONS=$(docker-compose -f $COMPOSE_FILE exec -T postgres psql -U projextpal -d projextpal -t -c "SELECT count(*) FROM pg_stat_activity;" 2>/dev/null | tr -d ' ')
    echo "   Active connections: $CONNECTIONS"
else
    echo -e "${RED}❌ PostgreSQL is not responding${NC}"
fi

echo ""

# ============================================================
# 4. Redis Connection
# ============================================================
echo -e "${YELLOW}📮 Redis Health:${NC}"

REDIS_CHECK=$(docker-compose -f $COMPOSE_FILE exec -T redis redis-cli ping 2>&1)

if echo "$REDIS_CHECK" | grep -q "PONG"; then
    echo -e "${GREEN}✅ Redis is healthy${NC}"
    
    # Get memory usage
    REDIS_MEM=$(docker-compose -f $COMPOSE_FILE exec -T redis redis-cli info memory 2>/dev/null | grep "used_memory_human" | cut -d: -f2 | tr -d '\r')
    echo "   Memory usage: $REDIS_MEM"
else
    echo -e "${RED}❌ Redis is not responding${NC}"
fi

echo ""

# ============================================================
# 5. Backend API Health
# ============================================================
echo -e "${YELLOW}🔧 Backend API Health:${NC}"

BACKEND_URL="http://localhost:8000/api/v1/health/"
BACKEND_CHECK=$(curl -s -o /dev/null -w "%{http_code}" $BACKEND_URL 2>/dev/null || echo "000")

if [ "$BACKEND_CHECK" = "200" ]; then
    echo -e "${GREEN}✅ Backend API is healthy${NC}"
    echo "   Endpoint: $BACKEND_URL"
else
    echo -e "${RED}❌ Backend API is not responding (HTTP $BACKEND_CHECK)${NC}"
fi

echo ""

# ============================================================
# 6. Frontend Health
# ============================================================
echo -e "${YELLOW}🌐 Frontend Health:${NC}"

FRONTEND_URL="http://localhost/health"
FRONTEND_CHECK=$(curl -s -o /dev/null -w "%{http_code}" $FRONTEND_URL 2>/dev/null || echo "000")

if [ "$FRONTEND_CHECK" = "200" ]; then
    echo -e "${GREEN}✅ Frontend is healthy${NC}"
    echo "   Endpoint: $FRONTEND_URL"
else
    echo -e "${RED}❌ Frontend is not responding (HTTP $FRONTEND_CHECK)${NC}"
fi

echo ""

# ============================================================
# 7. Tailscale Status
# ============================================================
echo -e "${YELLOW}🔐 Tailscale Status:${NC}"

TAILSCALE_STATUS=$(docker-compose -f $COMPOSE_FILE logs tailscale 2>&1 | tail -5)

if docker-compose -f $COMPOSE_FILE ps tailscale | grep -q "Up"; then
    echo -e "${GREEN}✅ Tailscale container is running${NC}"
    
    # Try to get Tailscale IP
    TS_IP=$(docker-compose -f $COMPOSE_FILE exec -T tailscale tailscale ip -4 2>/dev/null | tr -d '\r\n')
    if [ -n "$TS_IP" ]; then
        echo "   Tailscale IP: $TS_IP"
        echo "   Access at: http://$TS_IP"
    fi
else
    echo -e "${RED}❌ Tailscale is not running${NC}"
fi

echo ""

# ============================================================
# 8. Disk Space
# ============================================================
echo -e "${YELLOW}💾 Disk Space:${NC}"

DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')

df -h / | awk 'NR==2 {printf "   / : %s / %s (%s used)\n", $3, $2, $5}'

if [ "$DISK_USAGE" -lt 80 ]; then
    echo -e "${GREEN}✅ Disk space is good${NC}"
elif [ "$DISK_USAGE" -lt 90 ]; then
    echo -e "${YELLOW}⚠️  Disk space is getting low${NC}"
else
    echo -e "${RED}❌ Critical: Disk space is very low!${NC}"
fi

echo ""

# ============================================================
# 9. Recent Errors
# ============================================================
echo -e "${YELLOW}⚠️  Recent Errors (last hour):${NC}"

ERROR_COUNT=$(docker-compose -f $COMPOSE_FILE logs --since 1h 2>&1 | grep -i "error\|exception\|critical" | wc -l)

if [ $ERROR_COUNT -eq 0 ]; then
    echo -e "${GREEN}✅ No errors in the last hour${NC}"
else
    echo -e "${YELLOW}⚠️  Found $ERROR_COUNT errors/exceptions${NC}"
    echo ""
    echo "Recent errors:"
    docker-compose -f $COMPOSE_FILE logs --since 1h 2>&1 | grep -i "error\|exception\|critical" | tail -5
fi

echo ""

# ============================================================
# 10. Last Backup
# ============================================================
echo -e "${YELLOW}💾 Backup Status:${NC}"

if [ -d "./backups/database" ]; then
    LAST_BACKUP=$(ls -1t ./backups/database/db_backup_*.sql.gz 2>/dev/null | head -1)
    
    if [ -n "$LAST_BACKUP" ]; then
        BACKUP_DATE=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$LAST_BACKUP" 2>/dev/null || stat -c "%y" "$LAST_BACKUP" 2>/dev/null | cut -d' ' -f1-2)
        BACKUP_SIZE=$(du -h "$LAST_BACKUP" | cut -f1)
        BACKUP_AGE=$(( ($(date +%s) - $(stat -f "%m" "$LAST_BACKUP" 2>/dev/null || stat -c "%Y" "$LAST_BACKUP" 2>/dev/null)) / 3600 ))
        
        echo "   Last backup: $BACKUP_DATE ($BACKUP_SIZE)"
        echo "   Backup age: $BACKUP_AGE hours"
        
        if [ $BACKUP_AGE -lt 25 ]; then
            echo -e "${GREEN}✅ Backup is recent${NC}"
        else
            echo -e "${YELLOW}⚠️  Backup is old (>24 hours)${NC}"
        fi
    else
        echo -e "${RED}❌ No backups found!${NC}"
    fi
else
    echo -e "${RED}❌ Backup directory not found!${NC}"
fi

echo ""

# ============================================================
# Summary
# ============================================================
echo -e "${BLUE}📊 Health Check Summary:${NC}"
echo ""

HEALTH_SCORE=0

# Calculate health score (max 100)
[ $RUNNING -eq $TOTAL ] && ((HEALTH_SCORE+=20))
echo "$DB_CHECK" | grep -q "accepting connections" && ((HEALTH_SCORE+=20))
echo "$REDIS_CHECK" | grep -q "PONG" && ((HEALTH_SCORE+=15))
[ "$BACKEND_CHECK" = "200" ] && ((HEALTH_SCORE+=20))
[ "$FRONTEND_CHECK" = "200" ] && ((HEALTH_SCORE+=15))
[ "$DISK_USAGE" -lt 80 ] && ((HEALTH_SCORE+=10))

echo "   Overall Health Score: $HEALTH_SCORE/100"

if [ $HEALTH_SCORE -ge 90 ]; then
    echo -e "   Status: ${GREEN}EXCELLENT${NC}"
elif [ $HEALTH_SCORE -ge 70 ]; then
    echo -e "   Status: ${GREEN}GOOD${NC}"
elif [ $HEALTH_SCORE -ge 50 ]; then
    echo -e "   Status: ${YELLOW}FAIR - Needs attention${NC}"
else
    echo -e "   Status: ${RED}POOR - Immediate action required!${NC}"
fi

echo ""
echo "Health check completed at: $(date)"
echo ""
